a=5
num=input("Enter a number")
if num.isnumeric()==True:
    while(int(num)!=a):
        num=input("Enter the number again")
        if num.isnumeric()==False:
           print("Not a number")
           exit()
    print("Correct!")
else:
    print("Not a number")
