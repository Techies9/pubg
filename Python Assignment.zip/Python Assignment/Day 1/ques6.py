li=[]
add=0
mul=1
print("1. Add elements to list")
print("2. Stop adding")
a=int(input("Enter the value"))
while(a==1):
    b=int(input("Enter the value for the list"))
    li.append(b)
    print("1. Add elements to list")
    print("2. Stop adding")
    a=int(input("Enter the value"))
for i in li:
    add+=i
    mul*=i
print("Addition of list is :",add)
print("Multiplication of list is :",mul)
