l1=[]
print("Enter histogram")
a=int(input("Enter the value"))
while a!=-1:
    l1.append(a)
    a=int(input("Enter the value"))
for i in l1:
    for x in range(0,i):
        print("*",end="")
    print("\n")
