firstname=input("Enter your Firstname")
lastname=input("Enter your lastname")
wholename=firstname+"."+lastname
print(wholename)
