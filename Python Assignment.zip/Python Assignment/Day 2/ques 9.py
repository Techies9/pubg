def char_freq(word):
    word=word.replace(" ","")
    d={}
    k=0
    for i in word:
        d[i]=0
        t=word[k]
        for j in range(0,len(word)):
            if t==word[j]:
                d[i]=d.get(i)+1
        k+=1
    print(d)
word=input("Enter the word")
char_freq(word.lower())
