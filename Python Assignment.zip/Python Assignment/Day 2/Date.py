class Date:
    def __init__(self,day,month,year):
        self.day=day
        self.month=month
        self.year=year
    def printdate(self):
        print("entered date is:{0}\{1}\{2}".format(self.day,self.month,self.year))
