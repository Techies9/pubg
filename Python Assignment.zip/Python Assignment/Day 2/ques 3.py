li=[]
t=0
ll=[]
print("Enter a list of words (enter @ to stop adding elements)")
w=input()
while(w!='@'):
    li.append(w)
    w=input()
print(li)
for i in li:
   ll.append(len(i))
print(ll)
