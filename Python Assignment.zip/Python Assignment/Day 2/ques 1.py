def generate_n_chars(x,c):
    for i in range(0,x):
        print(c,end="")
n=int(input("Enter the interger"))
ch=input("Enter a character")
generate_n_chars(n,ch)
