def translate(word):
    di={"merry":"god","christmas":"jul","and":"och","happy":"gott","new":"nytt","year":"ar"}
    s=word.split(" ")
    flag=False
    li=[]
    for i in s:
        for j in range(len(di.keys())):
            if i==list(di.keys())[j]:
                flag=True
                li.append(di[list(di.keys())[j]])
        if flag==False:
            li.append(i)
        flag=False
    for i in li:
        print(i,end=" ",sep=" ")
        
    

word=input("Enter a string to convert")
translate(word)
