from math import*
#from numpy import*
print ("factorial(10):{0} Sqrt(10000):{1} sin(30):{2}".format(factorial(10),sqrt(10000),sin(30)))
